from pathlib import Path
import json
import os
import tempfile

# Configuração individual de cada usuário/PC.
PASTA_CONFIG = Path(os.environ.get("APPDATA") or (Path.home() / ".config")) / "ConversorPyXl"
ARQUIVO_CONFIG = PASTA_CONFIG / "config.json"
AVISO = ""


def carregar_caminho(padrao):
    global AVISO
    if not ARQUIVO_CONFIG.exists():
        return Path(padrao)
    try:
        dados = json.loads(ARQUIVO_CONFIG.read_text(encoding="utf-8"))
        caminho = dados["planilha"]
        if not isinstance(caminho, str) or not caminho:
            raise ValueError("Caminho inválido")
        arquivo = Path(caminho)
        if not arquivo.is_absolute() or arquivo.suffix.lower() != ".xlsx":
            raise ValueError("Caminho inválido")
        # Manter o caminho de rede mesmo quando a rede estiver indisponível.
        return arquivo
    except (OSError, ValueError, KeyError, TypeError):
        AVISO = "Não foi possível ler a configuração. Confira o local da planilha antes de cadastrar."
        return Path(padrao)


def salvar_caminho(caminho):
    PASTA_CONFIG.mkdir(parents=True, exist_ok=True)
    descritor, nome = tempfile.mkstemp(dir=PASTA_CONFIG, suffix=".tmp")
    temporario = Path(nome)
    try:
        with os.fdopen(descritor, "w", encoding="utf-8") as arquivo:
            json.dump({"planilha": str(caminho)}, arquivo, ensure_ascii=False, indent=2)
        os.replace(temporario, ARQUIVO_CONFIG)
    finally:
        temporario.unlink(missing_ok=True)
