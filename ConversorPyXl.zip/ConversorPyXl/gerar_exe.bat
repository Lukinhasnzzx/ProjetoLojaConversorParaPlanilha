@echo off
cd /d "%~dp0"
python -m pip install -r requirements-build.txt
if errorlevel 1 goto erro
python -m PyInstaller --noconfirm --clean --onedir --windowed --name ConversorPyXl main.py
if errorlevel 1 goto erro
echo.
echo Pronto! Envie a pasta dist\ConversorPyXl inteira.
echo A planilha nao e incluida automaticamente. Selecione o local pelo aplicativo.
pause
exit /b 0
:erro
echo Falha ao gerar. Confira o erro acima e o Python instalado.
pause
exit /b 1
