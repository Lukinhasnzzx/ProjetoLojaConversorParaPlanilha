import tkinter as tk
from tkinter import messagebox
import planilha
import os
import sys
import subprocess
from tkinter import filedialog


def limpar_campos(entradas):
    for campo in entradas:
        campo.delete(0, tk.END)

    entradas[0].focus_set()


def mostrar_dados(entradas):
    (
        entrada_sku,
        entrada_produto,
        entrada_compra,
        entrada_loja,
        entrada_quantidade,
        entrada_ml_unitario,
        entrada_apos_taxas,
        entrada_concorrente
    ) = entradas

    sku = entrada_sku.get().strip()
    produto = entrada_produto.get().strip()

    if not sku:
        messagebox.showwarning(
            "Campo vazio",
            "Preencha o SKU."
        )
        return

    if not produto:
        messagebox.showwarning(
            "Campo vazio",
            "Preencha o nome do produto."
        )
        return

    try:
        preco_compra = float(
            entrada_compra.get().strip().replace(",", ".")
        )

        preco_loja = float(
            entrada_loja.get().strip().replace(",", ".")
        )

        quantidade_kit = int(
            entrada_quantidade.get().strip()
        )

        preco_ml_unitario = float(
            entrada_ml_unitario.get().strip().replace(",", ".")
        )

        valor_apos_taxas_ml = float(
            entrada_apos_taxas.get().strip().replace(",", ".")
        )

        media_concorrente = float(
            entrada_concorrente.get().strip().replace(",", ".")
        )

        valores = [
            preco_compra,
            preco_loja,
            preco_ml_unitario,
            valor_apos_taxas_ml,
            media_concorrente
        ]

        if any(valor < 0 for valor in valores):
            messagebox.showwarning(
                "Valor inválido",
                "Os preços não podem ser negativos."
            )
            return

        if quantidade_kit < 1:
            messagebox.showwarning(
                "Quantidade inválida",
                "O kit deve ter pelo menos uma unidade."
            )
            return

    except ValueError:
        messagebox.showwarning(
            "Número inválido",
            "Preencha os preços com números, como 12,50.\n"
            "A quantidade do kit deve ser inteira, como 5."
        )
        return

    try:
        linha = planilha.cadastrar_produto(
            sku,
            produto,
            preco_compra,
            preco_loja,
            quantidade_kit,
            preco_ml_unitario,
            valor_apos_taxas_ml,
            media_concorrente
        )

    except PermissionError as erro:
        messagebox.showerror(
            "Planilha indisponível",
            str(erro) + "\n\nFeche a planilha no Calc/Excel e confira as permissões da pasta."
        )
        return

    except ValueError as erro:
        messagebox.showerror(
            "Dados inválidos",
            str(erro)
        )
        return

    except Exception as erro:
        messagebox.showerror(
            "Falha ao salvar",
            "Não foi possível concluir o cadastro. Os campos foram mantidos.\n\n"
            f"Detalhes: {erro}"
        )
        return

    messagebox.showinfo(
        "Produto salvo",
        f"{produto} foi cadastrado na linha {linha}!"
    )

    limpar_campos(entradas)


def abrir_cadastro(tela_inicial, tela_cadastro, entrada_sku):
    tela_inicial.pack_forget()
    tela_cadastro.pack(fill="both", expand=True)
    entrada_sku.focus_set()

def voltar_inicio(tela_inicial, tela_cadastro, entradas):
    tem_dados = any(
        entrada.get().strip() for entrada in entradas
    )

    if tem_dados:
        descartar = messagebox.askyesno(
            "Cadastro não salvo",
            "Voltar e descartar os dados preenchidos?"
        )

        if not descartar:
            return

    limpar_campos(entradas)

    tela_cadastro.pack_forget()
    tela_inicial.pack(fill="both", expand=True)

def abrir_planilha():
    if not planilha.ARQUIVO.exists():
        messagebox.showinfo(
            "Planilha não encontrada",
            "Cadastre um produto primeiro para criar a planilha."
        )
        return

    try:
        if sys.platform == "win32":
            os.startfile(str(planilha.ARQUIVO))

        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(planilha.ARQUIVO)])

        else:
            subprocess.Popen(["xdg-open", str(planilha.ARQUIVO)])

    except OSError as erro:
        messagebox.showerror(
            "Não foi possível abrir",
            f"Confira se há um aplicativo associado a arquivos .xlsx.\n\n{erro}"
        )

def sair_programa(janela, entradas):
    tem_dados = any(
        entrada.get().strip() for entrada in entradas
    )

    if tem_dados:
        sair = messagebox.askyesno(
            "Cadastro não salvo",
            "Há dados preenchidos que não foram salvos.\n\n"
            "Deseja descartar esses dados e sair?",
            parent=janela
        )

        if not sair:
            return

    janela.destroy()

def selecionar_planilha(janela, local_planilha):
    existente = messagebox.askyesnocancel(
        "Selecionar planilha",
        "Deseja usar uma planilha existente?\n\n"
        "Sim: selecionar um arquivo existente.\n"
        "Não: escolher onde criar uma nova planilha.",
        parent=janela
    )
    if existente is None:
        return

    opcoes = {
        "parent": janela,
        "filetypes": [("Planilha Excel", "*.xlsx")]
    }
    if planilha.ARQUIVO.parent.is_dir():
        opcoes["initialdir"] = str(planilha.ARQUIVO.parent)

    if existente:
        caminho = filedialog.askopenfilename(
            title="Escolha a planilha de produtos", **opcoes
        )
    else:
        caminho = filedialog.asksaveasfilename(
            title="Escolha onde criar a planilha",
            initialfile="produtos.xlsx",
            defaultextension=".xlsx",
            **opcoes
        )
    if not caminho:
        return

    try:
        planilha.selecionar_arquivo(caminho)
    except Exception as erro:
        messagebox.showerror("Não foi possível selecionar", str(erro), parent=janela)
        return

    local_planilha.set(f"Planilha selecionada:\n{planilha.ARQUIVO}")
    messagebox.showinfo(
        "Local salvo",
        "Este local será usado para cadastrar e abrir os produtos.\n"
        "Se o arquivo for novo, será criado no primeiro cadastro.\n\n"
        "A seleção não move nem copia a planilha anterior.",
        parent=janela
    )
