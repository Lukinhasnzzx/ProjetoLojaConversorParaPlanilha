import tkinter as tk
import interface.funcoes as funcoes
import planilha
import configuracao


janela = tk.Tk()
janela.title("MR Soluções — Cadastro de produtos")
janela.geometry("800x850")

tela_inicial = tk.Frame(janela)
tela_cadastro = tk.Frame(janela)

tela_inicial.pack(fill="both", expand=True)

# Tela inicial
titulo = tk.Label(
    tela_inicial,
    text="Cadastro de produtos MR SOLUCOESSSSS",
    font=("Segoe UI", 18)
)
titulo.pack(pady=20)

# SKU
texto_sku = tk.Label(
    tela_cadastro,
    text="Código SKU/barras:",
    font=("Segoe UI", 11)
)
texto_sku.pack(pady=(10, 5))

entrada_sku = tk.Entry(
    tela_cadastro,
    font=("Segoe UI", 11),
    width=30
)
entrada_sku.pack()

# Nome do produto
texto_produto = tk.Label(
    tela_cadastro,
    text="Nome do produto:",
    font=("Segoe UI", 11)
)
texto_produto.pack(pady=(15, 5))

entrada_produto = tk.Entry(
    tela_cadastro,
    font=("Segoe UI", 11),
    width=30
)
entrada_produto.pack()

# Preço de compra
texto_compra = tk.Label(
    tela_cadastro,
    text="Preço de compra por unidade (R$):",
    font=("Segoe UI", 11)
)
texto_compra.pack(pady=(15, 5))

entrada_compra = tk.Entry(
    tela_cadastro,
    font=("Segoe UI", 11),
    width=30
)
entrada_compra.pack()

# Venda na loja
texto_loja = tk.Label(
    tela_cadastro,
    text="Preço de venda na loja por unidade (R$):",
    font=("Segoe UI", 11)
)
texto_loja.pack(pady=(15, 5))

entrada_loja = tk.Entry(
    tela_cadastro,
    font=("Segoe UI", 11),
    width=30
)
entrada_loja.pack()

# Quantidade no kit ML
texto_quantidade = tk.Label(
    tela_cadastro,
    text="Quantidade de unidades no kit ML:",
    font=("Segoe UI", 11)
)
texto_quantidade.pack(pady=(15, 5))

entrada_quantidade = tk.Entry(
    tela_cadastro,
    font=("Segoe UI", 11),
    width=30
)
entrada_quantidade.pack()

# Venda unitária no ML
texto_ml_unitario = tk.Label(
    tela_cadastro,
    text="Preço de venda no ML por unidade (R$):",
    font=("Segoe UI", 11)
)
texto_ml_unitario.pack(pady=(15, 5))

entrada_ml_unitario = tk.Entry(
    tela_cadastro,
    font=("Segoe UI", 11),
    width=30
)
entrada_ml_unitario.pack()

# Valor do kit após taxas ML
texto_apos_taxas = tk.Label(
    tela_cadastro,
    text="Valor do kit após taxas ML, antes da NF (R$):",
    font=("Segoe UI", 11)
)
texto_apos_taxas.pack(pady=(15, 5))

entrada_apos_taxas = tk.Entry(
    tela_cadastro,
    font=("Segoe UI", 11),
    width=30
)
entrada_apos_taxas.pack()

# Média dos concorrentes
texto_concorrente = tk.Label(
    tela_cadastro,
    text="Preço médio do kit equivalente dos concorrentes (R$):",
    font=("Segoe UI", 11)
)
texto_concorrente.pack(pady=(15, 5))

entrada_concorrente = tk.Entry(
    tela_cadastro,
    font=("Segoe UI", 11),
    width=30
)
entrada_concorrente.pack()

# Lista entregue às funções
entradas = [
    entrada_sku,
    entrada_produto,
    entrada_compra,
    entrada_loja,
    entrada_quantidade,
    entrada_ml_unitario,
    entrada_apos_taxas,
    entrada_concorrente
]

# Botão da tela inicial
botao_adicionar = tk.Button(
    tela_inicial,
    text="Adicionar produto",
    font=("Segoe UI", 11),
    width=25,
    command=lambda: funcoes.abrir_cadastro(
        tela_inicial,
        tela_cadastro,
        entrada_sku
    )
)
botao_adicionar.pack(pady=10)

botao_planilha = tk.Button(
    tela_inicial,
    text="Ver produtos adicionados",
    font=("Segoe UI", 11),
    width=25,
    command=funcoes.abrir_planilha
)
botao_planilha.pack(pady=10)

local_planilha = tk.StringVar(
    value=f"Planilha selecionada:\n{planilha.ARQUIVO}"
)

botao_selecionar = tk.Button(
    tela_inicial,
    text="Selecionar planilha",
    font=("Segoe UI", 11),
    width=25,
    command=lambda: funcoes.selecionar_planilha(janela, local_planilha)
)
botao_selecionar.pack(pady=10)

tk.Label(
    tela_inicial,
    textvariable=local_planilha,
    font=("Segoe UI", 10),
    wraplength=700
).pack(pady=15)

botao_sair = tk.Button(
    tela_inicial,
    text="Sair",
    font=("Segoe UI", 11),
    width=25,
    command=lambda: funcoes.sair_programa(
        janela,
        entradas
    )
)
botao_sair.pack(pady=10)

# Botão da tela de cadastro
botao_salvar = tk.Button(
    tela_cadastro,
    text="Salvar produto",
    font=("Segoe UI", 11),
    command=lambda: funcoes.mostrar_dados(entradas)
)
botao_salvar.pack(pady=20)

botao_voltar = tk.Button(
    tela_cadastro,
    text="Voltar",
    font=("Segoe UI", 11),
    command=lambda: funcoes.voltar_inicio(
        tela_inicial,
        tela_cadastro,
        entradas
    )
)
botao_voltar.pack(pady=5)

janela.protocol(
    "WM_DELETE_WINDOW",
    lambda: funcoes.sair_programa(janela, entradas)
)

if configuracao.AVISO:
    janela.after(100, lambda: funcoes.messagebox.showwarning(
        "Configuração", configuracao.AVISO, parent=janela
    ))

janela.mainloop()