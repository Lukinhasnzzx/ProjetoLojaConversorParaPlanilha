from pathlib import Path
from math import isfinite
from datetime import datetime
import shutil
import tempfile
import os

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import CellIsRule
from openpyxl.formatting.formatting import ConditionalFormattingList
from openpyxl.workbook.properties import CalcProperties


import sys
from contextlib import contextmanager
from functools import wraps
import configuracao

if getattr(sys, "frozen", False):
    PASTA_PROGRAMA = Path(sys.executable).resolve().parent
else:
    PASTA_PROGRAMA = Path(__file__).resolve().parent

ARQUIVO = configuracao.carregar_caminho(PASTA_PROGRAMA / "produtos.xlsx")


@contextmanager
def bloquear_cadastro():
    # Exclusão entre instâncias que usam o mesmo arquivo compartilhado.
    bloqueio = ARQUIVO.with_name(ARQUIVO.name + ".cadastro.lock")
    try:
        descritor = os.open(bloqueio, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise PermissionError(
            "Outro computador está cadastrando nesta planilha. "
            "Aguarde e tente novamente. Se o programa travou, confirme que "
            "ninguém está cadastrando antes de remover o arquivo "
            f"{bloqueio.name}."
        ) from None

    try:
        with os.fdopen(descritor, "w", encoding="utf-8") as arquivo:
            arquivo.write(f"Computador: {__import__('socket').gethostname()}\nPID: {os.getpid()}\n")
        yield
    finally:
        bloqueio.unlink(missing_ok=True)


def cadastro_exclusivo(funcao):
    @wraps(funcao)
    def executar(*args, **kwargs):
        with bloquear_cadastro():
            return funcao(*args, **kwargs)
    return executar


def selecionar_arquivo(caminho):
    global ARQUIVO
    novo = Path(caminho).expanduser().absolute()
    if novo.suffix.lower() != ".xlsx":
        raise ValueError("Escolha um arquivo .xlsx.")
    if not novo.parent.is_dir():
        raise FileNotFoundError("A pasta escolhida não está disponível.")
    if novo.exists():
        livro = openpyxl.load_workbook(novo)
        try:
            if "Produtos" not in livro.sheetnames:
                raise ValueError("O arquivo deve ter uma aba chamada Produtos.")
            colunas, _ = organizar_colunas()
            conferir_cabecalhos(livro["Produtos"], colunas)
        finally:
            livro.close()
    configuracao.salvar_caminho(novo)
    ARQUIVO = novo


CAMPOS = [
    ("CÓDIGO SKU (BARRAS)", "texto"),
    ("Produto", "texto"),
    ("Compra por unidade", "moeda"),

    ("Venda loja (unidade)", "moeda"),
    ("Lucro loja (unidade)", "moeda"),
    ("Margem loja", "percentual"),

    ("Quantidade no kit ML", "inteiro"),
    ("Venda ML por unidade", "moeda"),
    ("Venda ML do kit", "moeda"),

    ("Valor após taxas ML (kit)", "moeda"),
    ("Valor final ML após NF", "moeda"),
    ("Lucro ML (kit)", "moeda"),
    ("Margem ML", "percentual"),

    ("Média concorrente ML (kit)", "moeda")
]


def organizar_colunas():
    colunas = {}
    colunas_vazias = []
    numero_coluna = 1

    separadores = {
        "Compra por unidade": 2,
        "Margem loja": 1,
        "Venda ML do kit": 1,
        "Margem ML": 1
    }

    for titulo, formato in CAMPOS:
        colunas[titulo] = get_column_letter(numero_coluna)
        numero_coluna += 1

        quantidade_espacos = separadores.get(titulo, 0)

        for _ in range(quantidade_espacos):
            colunas_vazias.append(
                get_column_letter(numero_coluna)
            )
            numero_coluna += 1

    return colunas, colunas_vazias


def validar_dados(
    codigo_sku,
    produto,
    preco_compra,
    preco_loja,
    quantidade_kit,
    preco_ml_unitario,
    valor_apos_taxas_ml,
    media_concorrente
):
    if not str(codigo_sku).strip():
        raise ValueError("O código SKU não pode ficar vazio.")

    if not str(produto).strip():
        raise ValueError("O nome do produto não pode ficar vazio.")

    valores = {
        "Preço de compra": preco_compra,
        "Preço de venda na loja": preco_loja,
        "Preço de venda ML por unidade": preco_ml_unitario,
        "Valor após taxas ML": valor_apos_taxas_ml,
        "Média dos concorrentes": media_concorrente
    }

    for nome, valor in valores.items():
        if (
            isinstance(valor, bool)
            or not isinstance(valor, (int, float))
            or not isfinite(valor)
            or valor < 0
        ):
            raise ValueError(
                f"{nome} deve ser um número válido maior ou igual a zero."
            )

    if (
        isinstance(quantidade_kit, bool)
        or not isinstance(quantidade_kit, int)
        or quantidade_kit < 1
    ):
        raise ValueError(
            "A quantidade do kit deve ser um número inteiro maior que zero."
        )


def conferir_cabecalhos(aba, colunas):
    # Permitir uma aba completamente vazia
    if aba.max_row == 1 and all(
        celula.value is None for celula in aba[1]
    ):
        return

    for titulo, formato in CAMPOS:
        coluna = colunas[titulo]

        if aba[f"{coluna}1"].value != titulo:
            raise ValueError(
                "A planilha existente tem uma estrutura diferente "
                "da esperada. Confira o arquivo produtos.xlsx."
            )


def aplicar_formulas(aba, linha, colunas):
    compra = f"{colunas['Compra por unidade']}{linha}"
    venda_loja = f"{colunas['Venda loja (unidade)']}{linha}"
    lucro_loja = f"{colunas['Lucro loja (unidade)']}{linha}"

    quantidade = f"{colunas['Quantidade no kit ML']}{linha}"
    venda_unitaria_ml = f"{colunas['Venda ML por unidade']}{linha}"
    venda_kit_ml = f"{colunas['Venda ML do kit']}{linha}"

    apos_taxas = f"{colunas['Valor após taxas ML (kit)']}{linha}"
    valor_final = f"{colunas['Valor final ML após NF']}{linha}"
    lucro_ml = f"{colunas['Lucro ML (kit)']}{linha}"

    # Loja: venda e lucro por unidade
    aba[lucro_loja] = f"=ROUND({venda_loja}-{compra},2)"

    aba[f"{colunas['Margem loja']}{linha}"] = (
        f'=IF({venda_loja}>0,{lucro_loja}/{venda_loja},"")'
    )

    # ML: valor total de venda do kit
    aba[venda_kit_ml] = (
        f"=ROUND({venda_unitaria_ml}*{quantidade},2)"
    )

    # NF fixa de 4% sobre a venda bruta do kit
    aba[valor_final] = (
        f"=ROUND({apos_taxas}-ROUND({venda_kit_ml}*0.04,2),2)"
    )

    # Lucro do kit após descontar o custo de compra
    aba[lucro_ml] = (
        f"=ROUND({valor_final}-ROUND({compra}*{quantidade},2),2)"
    )

    aba[f"{colunas['Margem ML']}{linha}"] = (
        f'=IF({venda_kit_ml}>0,{lucro_ml}/{venda_kit_ml},"")'
    )


def formatar_planilha(aba, colunas, colunas_vazias, ultima_linha):
    lado = Side(style="thin", color="A0A0A0")

    borda = Border(
        left=lado,
        right=lado,
        top=lado,
        bottom=lado
    )

    campos_calculados = [
        "Lucro loja (unidade)",
        "Margem loja",
        "Venda ML do kit",
        "Valor final ML após NF",
        "Lucro ML (kit)",
        "Margem ML"
    ]

    larguras = {
        "CÓDIGO SKU (BARRAS)": 28,
        "Produto": 38,
        "Compra por unidade": 22,
        "Venda loja (unidade)": 22,
        "Lucro loja (unidade)": 22,
        "Margem loja": 18,
        "Quantidade no kit ML": 20,
        "Venda ML por unidade": 22,
        "Venda ML do kit": 22,
        "Valor após taxas ML (kit)": 25,
        "Valor final ML após NF": 25,
        "Lucro ML (kit)": 22,
        "Margem ML": 18,
        "Média concorrente ML (kit)": 26
    }

    for titulo, formato in CAMPOS:
        coluna = colunas[titulo]

        cabecalho = aba[f"{coluna}1"]
        cabecalho.value = titulo
        cabecalho.font = Font(bold=True, color="FFFFFF")
        cabecalho.fill = PatternFill(
            fill_type="solid",
            fgColor="008542"
        )
        cabecalho.alignment = Alignment(
            horizontal="center",
            vertical="center",
            wrap_text=True
        )
        cabecalho.border = borda

        aba.column_dimensions[coluna].width = larguras[titulo]

        for linha in range(2, ultima_linha + 1):
            if aba[f"A{linha}"].value is None:
                continue

            celula = aba[f"{coluna}{linha}"]

            # Alternar entre uma linha mais escura e outra mais clara
            cor_fundo = "C5DFCF" if linha % 2 == 0 else "F0F7F3"

            celula.fill = PatternFill(
                fill_type="solid",
                fgColor=cor_fundo
            )
            celula.border = borda
            celula.font = Font(
                color="000000",
                bold=titulo in campos_calculados
            )

            if formato == "texto":
                celula.number_format = "@"
                alinhamento = "left"

            elif formato == "moeda":
                celula.number_format = '"R$" #,##0.00'
                alinhamento = "right"

            elif formato == "percentual":
                celula.number_format = "0.00%"
                alinhamento = "center"

            else:
                celula.number_format = "0"
                alinhamento = "center"

            celula.alignment = Alignment(
                horizontal=alinhamento,
                vertical="center"
            )

    for coluna in colunas_vazias:
        aba.column_dimensions[coluna].width = 4

    aba.row_dimensions[1].height = 42

    for linha in range(2, ultima_linha + 1):
        aba.row_dimensions[linha].height = 26

    aba.freeze_panes = "A2"
    aba.sheet_view.showGridLines = False

    # Regras dinâmicas de cores
    aba.conditional_formatting = ConditionalFormattingList()

    fonte_vermelha = Font(color="C00000", bold=True)
    fonte_verde = Font(color="008542", bold=True)

    for titulo in ["Margem loja", "Margem ML"]:
        coluna = colunas[titulo]
        intervalo = f"{coluna}2:{coluna}{ultima_linha}"

        aba.conditional_formatting.add(
            intervalo,
            CellIsRule(
                operator="lessThan",
                formula=["0.36"],
                font=fonte_vermelha
            )
        )

        aba.conditional_formatting.add(
            intervalo,
            CellIsRule(
                operator="greaterThanOrEqual",
                formula=["0.36"],
                font=fonte_verde
            )
        )

    for titulo in ["Lucro loja (unidade)", "Lucro ML (kit)"]:
        coluna = colunas[titulo]
        intervalo = f"{coluna}2:{coluna}{ultima_linha}"

        aba.conditional_formatting.add(
            intervalo,
            CellIsRule(
                operator="lessThan",
                formula=["0"],
                font=fonte_vermelha
            )
        )

        aba.conditional_formatting.add(
            intervalo,
            CellIsRule(
                operator="greaterThanOrEqual",
                formula=["0"],
                font=fonte_verde
            )
        )

def verificar_planilha_disponivel():
    if not ARQUIVO.exists():
        return

    # Arquivo de bloqueio criado pelo LibreOffice
    bloqueio_calc = ARQUIVO.parent / f".~lock.{ARQUIVO.name}#"

    # Arquivo temporário normalmente criado pelo Excel
    bloqueio_excel = ARQUIVO.parent / f"~${ARQUIVO.name}"

    if bloqueio_calc.exists() or bloqueio_excel.exists():
        raise PermissionError(
            "Feche a planilha antes de cadastrar um produto."
        )

    # Conferir se o arquivo permite acesso para escrita
    try:
        with open(ARQUIVO, "r+b"):
            pass
    except PermissionError:
        raise PermissionError(
            "A planilha está aberta ou sem permissão de escrita."
        )
    
def salvar_com_backup(planilha):
    # O temporário fica no mesmo disco para permitir substituição atômica.
    descritor, nome = tempfile.mkstemp(
        prefix=".produtos_", suffix=".xlsx", dir=ARQUIVO.parent
    )
    os.close(descritor)
    temporario = Path(nome)

    try:
        planilha.save(temporario)
        verificar_planilha_disponivel()

        if ARQUIVO.exists():
            pasta_backup = ARQUIVO.parent / "backups"
            pasta_backup.mkdir(exist_ok=True)
            data = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            backup = pasta_backup / f"produtos_{data}.xlsx"
            shutil.copy2(ARQUIVO, backup)

        os.replace(temporario, ARQUIVO)
    finally:
        temporario.unlink(missing_ok=True)


@cadastro_exclusivo
def cadastrar_produto(
    codigo_sku,
    produto,
    preco_compra,
    preco_loja,
    quantidade_kit,
    preco_ml_unitario,
    valor_apos_taxas_ml,
    media_concorrente
):
    validar_dados(
        codigo_sku,
        produto,
        preco_compra,
        preco_loja,
        quantidade_kit,
        preco_ml_unitario,
        valor_apos_taxas_ml,
        media_concorrente
    )

    colunas, colunas_vazias = organizar_colunas()

    verificar_planilha_disponivel()

    if ARQUIVO.exists():
        planilha = openpyxl.load_workbook(ARQUIVO)
    else:
        planilha = openpyxl.Workbook()
        planilha.active.title = "Produtos"

    try:
        if "Produtos" not in planilha.sheetnames:
            raise ValueError(
                "A planilha precisa ter uma aba chamada Produtos."
            )

        aba = planilha["Produtos"]
        conferir_cabecalhos(aba, colunas)

        ultima_linha = 1

        for linha in range(2, aba.max_row + 1):
            if aba[f"A{linha}"].value is not None:
                ultima_linha = linha
                sku_existente = str(aba[f"A{linha}"].value).strip()
                if sku_existente.casefold() == str(codigo_sku).strip().casefold():
                    raise ValueError(
                        f"O SKU {codigo_sku} já está cadastrado na linha {linha}."
                    )

        nova_linha = ultima_linha + 1

        dados = {
            "CÓDIGO SKU (BARRAS)": str(codigo_sku).strip(),
            "Produto": str(produto).strip(),
            "Compra por unidade": preco_compra,
            "Venda loja (unidade)": preco_loja,
            "Quantidade no kit ML": quantidade_kit,
            "Venda ML por unidade": preco_ml_unitario,
            "Valor após taxas ML (kit)": valor_apos_taxas_ml,
            "Média concorrente ML (kit)": media_concorrente
        }

        for titulo, valor in dados.items():
            celula = aba[f"{colunas[titulo]}{nova_linha}"]
            celula.value = valor

            # Garantir que SKU e nome sejam armazenados como texto
            if titulo in ["CÓDIGO SKU (BARRAS)", "Produto"]:
                celula.data_type = "s"

        for linha in range(2, nova_linha + 1):
            if aba[f"A{linha}"].value is not None:
                aplicar_formulas(aba, linha, colunas)

        formatar_planilha(
            aba,
            colunas,
            colunas_vazias,
            nova_linha
        )

        planilha.calculation = CalcProperties(
            calcMode="auto",
            fullCalcOnLoad=True,
            forceFullCalc=True
        )

        salvar_com_backup(planilha)

    finally:
        planilha.close()

    return nova_linha